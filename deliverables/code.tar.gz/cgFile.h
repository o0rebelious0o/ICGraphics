#ifndef CGFILE_H
#define CGFILE_H

#include <fstream>
#include <iostream>
#include <string>
#include <vector>

using namespace std;


void readVTK(void);
void readTexture(void);

#endif

